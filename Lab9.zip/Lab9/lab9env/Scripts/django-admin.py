#!c:\users\daniyar\desktop\4 semester\webdev\week10\hw10env\scripts\python.exe
from django.core import management

if __name__ == "__main__":
    management.execute_from_command_line()
