export const CATEGORIES_WITH_PRODUCTS = [
  {
    name: 'Электроника',
    id: 1,
    products: [
      {
        id: 10,
        categoryId: 1,
        name: 'Laptop',
        description: 'Hey, Laptops are cool!'
      },
      {
        id: 11,
        categoryId: 1,
        name: 'Laptop',
        description: 'Hey, Laptops are cool!'
      },
      {
        id: 12,
        categoryId: 1,
        name: 'Laptop',
        description: 'Hey, Laptops are cool!'
      },
    ]
  },
  {
    name: 'Дом',
    id: 2,
    products: [
      {
        id: 20,
        categoryId: 2,
        name: 'Sofa',
        description: 'Hey, Sofas are cool!'
      }
    ]
  },
  {
    name: 'Одежда',
    id: 3,
    products: [
      {
        id: 30,
        categoryId: 3,
        name: 'ZARA',
        description: 'Hey, T-shirts are cool!'
      }
    ]
  },
  {
    name: 'Косметика',
    id: 4,
    products: [
      {
        id: 40,
        categoryId: 4,
        name: 'Lipstick',
        description: 'Hey, Lipsticks are cool!'
      }
    ]
  }
]

